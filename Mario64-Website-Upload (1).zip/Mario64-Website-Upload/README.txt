MARIO 64 STATIC WEBSITE PACKAGE

Full website assets are included: index.html, .js, .wasm.
No Node.js, npm or installer is needed.

LOCAL WINDOWS:
1. Install Python if it is not installed.
2. Double-click START-LOCAL.bat (or run: py -m http.server 8000 --bind 127.0.0.1).
3. Visit http://127.0.0.1:8000/

PUBLIC STATIC WEB HOST:
Upload index.html, sm64.us.f3dex2e.js and sm64.us.f3dex2e.wasm to the SAME directory (usually public_html, www, or site root).
The server must serve .wasm files as application/wasm (most modern hosts do).
Check rights/permissions before publishing copyrighted game assets.

SECURITY:
This is third-party code, repackaged from your uploaded sm64-main(1).zip, and not fully security audited.
The original external Bootstrap CDN stylesheet was removed. Do not run on a PC containing crypto funds unless you accept that risk; an isolated machine/VM is safer.
